import azure.functions as func
import os, requests
from datetime import datetime, timedelta

def main(req: func.HttpRequest)->func.HttpResponse:
    code=req.params.get("code")
    tenant=os.getenv("TENANT_ID")
    client=os.getenv("CLIENT_ID")
    red=os.getenv("REDIRECT_URI")

    token_url=f"https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token"
    data={"client_id":client,"grant_type":"authorization_code","code":code,"redirect_uri":red}

    token=requests.post(token_url,data=data).json().get("access_token")
    if not token:
        return func.HttpResponse("Token failed",status_code=500)

    resp=func.HttpResponse("Login OK",status_code=200)
    exp=datetime.utcnow()+timedelta(hours=1)
    resp.headers.add("Set-Cookie",
        f"auth_token={token}; HttpOnly; Secure; Path=/; Expires={exp:%a, %d %b %Y %H:%M:%S GMT}")
    return resp
