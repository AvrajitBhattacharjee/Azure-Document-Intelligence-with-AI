import azure.functions as func
import os
from validate_jwt import validate_jwt

def main(req: func.HttpRequest)->func.HttpResponse:
    token=req.cookies.get("auth_token")
    if not token:
        return func.HttpResponse("Unauthorized",status_code=401)

    try:
        dec=validate_jwt(token, os.getenv("TENANT_ID"), os.getenv("CLIENT_ID"))
        return func.HttpResponse(f"Hello {dec.get('preferred_username')}",mimetype="text/plain")
    except:
        return func.HttpResponse("Unauthorized",status_code=401)
