import jwt, requests, os

def validate_jwt(token, tenant, client_id):
    jwks_url=f"https://login.microsoftonline.com/{tenant}/discovery/v2.0/keys"
    jwks=requests.get(jwks_url).json()["keys"]
    key=jwks[0]
    public=jwt.algorithms.RSAAlgorithm.from_jwk(key)
    aud=f"api://{client_id}/access_as_user"
    return jwt.decode(token, public, algorithms=["RS256"], audience=aud,
                      issuer=f"https://login.microsoftonline.com/{tenant}/v2.0")
