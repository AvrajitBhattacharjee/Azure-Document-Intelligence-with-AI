import azure.functions as func
import os, urllib.parse

def main(req: func.HttpRequest)->func.HttpResponse:
    tenant=os.getenv("TENANT_ID")
    client=os.getenv("CLIENT_ID")
    red=os.getenv("REDIRECT_URI")

    url=(f"https://login.microsoftonline.com/{tenant}/oauth2/v2.0/authorize?"
         f"client_id={client}&response_type=code&redirect_uri={urllib.parse.quote(red)}"
         f"&response_mode=query&scope=openid profile email offline_access api://{client}/access_as_user")
    return func.HttpResponse(status_code=302,headers={"Location":url})
